<?php

if (isset($_POST['submit'])){
    $name=$POST['name'];
    $mailForm=$_POST['mail'];
    $message=$_POST['message'];

    $mailTo = "newgabselinaschoolenugu@gmail.com";
    $headers ="from: ".$mailfrom;
    $txt ="You have a message".$name".\n\n".$message;

    mail($mailTo, $name, $txt ,$header);

    header("lo cation:home.html?MessageSent");
}
?>